CREATE OR REPLACE PROCEDURE cariDataDummy (p_ID IN STAFF.StaffNo%TYPE)
IS
    v_Fname      STAFF.fname%TYPE;
    v_Lname      STAFF.lname%TYPE;
    v_sPosition  STAFF.sPosition%TYPE;  
    v_Sex        STAFF.Sex%TYPE;
    v_DoB        STAFF.Dob%TYPE;
    v_Salary     STAFF.Salary%TYPE;
    v_BranchNo   STAFF.BranchNo%TYPE;
    
    EmpNo_Out_of_range EXCEPTION;
BEGIN
    IF p_ID < 'AA01' OR p_ID > 'ZZ99' THEN 
        RAISE EmpNo_Out_of_range;
    ELSE
        SELECT fname, lname, sPosition, sex, DOB, salary, branchNo 
        INTO v_Fname, v_Lname, v_sPosition, v_sex, v_DoB, v_salary, v_branchNo
        FROM STAFF 
        WHERE staffNo = p_ID;
    
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Id Pegawai       : ' || p_ID);
        DBMS_OUTPUT.PUT_LINE('Nama Pegawai     : ' || v_Fname || ' ' || v_Lname);
        DBMS_OUTPUT.PUT_LINE('Cabang Kota      : ' || v_branchNo);
        DBMS_OUTPUT.PUT_LINE('Jabatan          : ' || v_sPosition);
        DBMS_OUTPUT.PUT_LINE('Gaji Pegawai     : ' || v_salary);
    END IF;
    
EXCEPTION 
    WHEN EmpNo_Out_of_range THEN
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Error: Nomor Staff tidak valid atau di luar jangkauan!');
    
    WHEN NO_DATA_FOUND THEN 
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Error: Data Staff tidak ditemukan!');
END;
/
