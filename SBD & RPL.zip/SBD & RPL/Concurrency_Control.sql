CREATE OR REPLACE PROCEDURE setortunai(
    p_NoRekening IN CHAR,
    p_NIK IN CHAR,
    p_Nominal IN NUMBER
) IS
    v_Total_Saldo NUMBER;
    v_Id_Transaksi NUMBER;
    start_dts DATE := SYSDATE;
    curr_dts DATE;
    eye NUMBER := 0;
BEGIN
    -- Ambil saldo awal
    SELECT Total_Saldo INTO v_Total_Saldo
    FROM Nasabah
    WHERE No_Rekening = p_NoRekening;

    -- Simulasi delay 10 detik
    LOOP
        eye := eye + 1;
        curr_dts := SYSDATE;
        EXIT WHEN curr_dts > start_dts + 0.20/(24*60); -- 10 detik
    END LOOP;

    -- Tambah saldo
    v_Total_Saldo := v_Total_Saldo + p_Nominal;

    -- Update saldo
    UPDATE Nasabah
    SET Total_Saldo = v_Total_Saldo
    WHERE No_Rekening = p_NoRekening;

    -- Generate id transaksi
    SELECT NVL(MAX(Id_Transaksi), 0) + 1 INTO v_Id_Transaksi FROM Transaksi;

    -- Catat transaksi
    INSERT INTO Transaksi (
        Id_Transaksi, No_Rekening, Id_JenisTransaksi,
        Nominal_Kredit, Nominal_Debet, Waktu, Saldo, NIK
    )
    VALUES (
        v_Id_Transaksi, p_NoRekening, '1',
        p_Nominal, 0, SYSTIMESTAMP, v_Total_Saldo, p_NIK
    );

    COMMIT;
END;
/

CREATE OR REPLACE PROCEDURE tariktunai(
    p_NoRekening IN CHAR,
    p_NIK IN CHAR,
    p_Nominal IN NUMBER
) IS
    v_Total_Saldo NUMBER;
    v_Id_Transaksi NUMBER;
    start_dts DATE := SYSDATE;
    curr_dts DATE;
    eye NUMBER := 0;
BEGIN
    -- Ambil saldo awal
    SELECT Total_Saldo INTO v_Total_Saldo
    FROM Nasabah
    WHERE No_Rekening = p_NoRekening;

    -- Simulasi delay 10 detik
    LOOP
        eye := eye + 1;
        curr_dts := SYSDATE;
        EXIT WHEN curr_dts > start_dts + 0.20/(24*60); -- 10 detik
    END LOOP;

    -- Kurangi saldo
    v_Total_Saldo := v_Total_Saldo - p_Nominal;

    -- Update saldo
    UPDATE Nasabah
    SET Total_Saldo = v_Total_Saldo
    WHERE No_Rekening = p_NoRekening;

    -- Generate id transaksi
    SELECT NVL(MAX(Id_Transaksi), 0) + 1 INTO v_Id_Transaksi FROM Transaksi;

    -- Catat transaksi
    INSERT INTO Transaksi (
        Id_Transaksi, No_Rekening, Id_JenisTransaksi,
        Nominal_Kredit, Nominal_Debet, Waktu, Saldo, NIK
    )
    VALUES (
        v_Id_Transaksi, p_NoRekening, '2',
        0, p_Nominal, SYSTIMESTAMP, v_Total_Saldo, p_NIK
    );

    COMMIT;
END;
/
