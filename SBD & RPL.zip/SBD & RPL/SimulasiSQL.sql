BEGIN
  FOR i IN 1..10 LOOP
    INSERT INTO kategori VALUES (i, 'Kategori ' || i);
  END LOOP;
  COMMIT;
END;