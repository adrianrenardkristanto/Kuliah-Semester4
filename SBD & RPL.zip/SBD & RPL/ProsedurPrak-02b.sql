CREATE OR REPLACE FUNCTION rateSalary (salary IN STAFF.Salary%TYPE)
RETURN VARCHAR2
IS 
    rate VARCHAR2(20);
BEGIN 
    IF salary <= 100000 THEN
        rate := 'Rendah';
    ELSIF salary <= 200000 THEN
        rate := 'Sedang';
    ELSE
        rate := 'Tinggi';
    END IF;
    RETURN rate;
END;
/

CREATE OR REPLACE FUNCTION findCity (branchNo IN STAFF.BranchNo%TYPE)
RETURN VARCHAR2
IS 
    v_branchNo  STAFF.BranchNo%TYPE;
    v_City  VARCHAR2(100);
BEGIN 
    v_branchNo := branchNo;
   SELECT b.city 
    INTO v_City 
    FROM  BRANCH b WHERE branchNo = findCity.branchNo;

    RETURN v_City;

   EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'Unknown City';
    WHEN TOO_MANY_ROWS THEN
        RETURN 'Multiple Cities Found';
END;
/

CREATE OR REPLACE PROCEDURE cariData (p_ID IN STAFF.StaffNo%TYPE)
IS
    v_Fname      STAFF.fname%TYPE;
    v_Lname      STAFF.lname%TYPE;
    v_sPosition  STAFF.sPosition%TYPE;  
    v_Salary     STAFF.Salary%TYPE;
    v_BranchNo   STAFF.BranchNo%TYPE;
    v_City       VARCHAR2(100);
    v_Rate       VARCHAR2(20);
    EmpNo_Out_of_range EXCEPTION;
    
BEGIN
    IF p_ID < 'AA01' OR p_ID > 'ZZ99' THEN 
        RAISE EmpNo_Out_of_range;
    ELSE
        SELECT s.fname, s.lname, s.sPosition,s.salary, s.branchNo
        INTO v_Fname, v_Lname, v_sPosition, v_salary, v_branchNo
        FROM STAFF s 
        WHERE s.staffNo = p_ID;

        v_Rate := rateSalary(v_salary);
        v_City := findCity(v_branchNo);
    
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Id Pegawai       : ' || p_ID);
        DBMS_OUTPUT.PUT_LINE('Nama Pegawai     : ' || v_Fname || ' ' || v_Lname);
        DBMS_OUTPUT.PUT_LINE('Cabang Kota      : ' || v_City || ' (' || v_branchNo || ')');
        DBMS_OUTPUT.PUT_LINE('Jabatan          : ' || v_sPosition);
        DBMS_OUTPUT.PUT_LINE('Gaji             : ' || v_salary || ' (' || v_Rate || ')');
    END IF;
    
EXCEPTION 
    WHEN EmpNo_Out_of_range THEN
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Error: Nomor Staff tidak valid atau di luar jangkauan!');
    
    WHEN NO_DATA_FOUND THEN 
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Error: Data Staff tidak ditemukan!');
END;
/
