SET SERVEROUTPUT ON;
SET VERIFY OFF;
ACCEPT p_ID PROMPT 'Masukan Batasan suku ke-n Prima : '
DECLARE
       v_suku NUMBER;
        v_counter NUMBER := 0;
        v_count Number;
        is_prime BOOLEAN;
       
BEGIN
    v_suku := '&p_ID';
    FOR v_count IN 2..v_suku LOOP
        is_prime := TRUE;
         FOR i IN 2..SQRT(v_count) LOOP
            IF v_count MOD i != 0 THEN
                is_prime := FALSE;
                EXIT;
            END IF;
        END LOOP;

        IF is_prime THEN
            DBMS_OUTPUT.PUT_LINE(v_count || ' adalah Bilangan Prima');
            v_counter := v_counter + 1;
         END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Total Bil. Prima ada : ' || v_counter);
END;
/
