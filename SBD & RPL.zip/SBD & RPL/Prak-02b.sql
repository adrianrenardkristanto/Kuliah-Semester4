/* Program : Memanggil record staff */
/* File name: C:\Lab\Prak-02.sql */
SET SERVEROUTPUT ON;
SET VERIFY OFF;
ACCEPT p_ID PROMPT 'Masukan Nomor Staff [AA99] : '
DECLARE
       v_ID         STAFF.StaffNo%TYPE;
       v_Fname      STAFF.fname%TYPE;
       v_Lname      STAFF.lname%TYPE;
       v_sPosition  STAFF.sPosition%TYPE;  
       v_Sex        STAFF.Sex%TYPE;
       v_DoB        STAFF.Dob%TYPE;
       v_Salary     STAFF.Salary%TYPE;
       v_BranchNo   STAFF.BranchNo%TYPE;
       v_Street     BRANCH.Street%TYPE;
       v_City       BRANCH.City%TYPE;
       v_Sex_Desc   VARCHAR2(10);
       EmpNo_Out_of_range EXCEPTION;
       
BEGIN
    v_ID := '&p_ID';
    IF v_ID < 'AA01' OR v_ID > 'ZZ99' THEN 
        RAISE EmpNo_Out_of_range;
    ELSE
        SELECT s.staffNo, s.fname, s.lname, s.sPosition, s.sex, s.DOB, s.salary, s.branchNo, b.street, b.city 
        INTO v_ID, v_Fname, v_Lname, v_sPosition, v_sex, v_DoB, v_salary, v_branchNo, v_Street,v_City  
        FROM STAFF s JOIN BRANCH b ON s.branchNo = b.branchNo 
        WHERE s.staffNo = v_ID;
    
        IF v_sex = 'M' THEN 
            v_Sex_Desc := 'Pria';
        ELSE
            v_Sex_Desc := 'Wanita';
        END IF;
        
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('No Staff         : ' || v_ID);
        DBMS_OUTPUT.PUT_LINE('Nama Staff       : ' || v_Fname || ' ' || v_Lname);
        DBMS_OUTPUT.PUT_LINE('Cabang           : ' || v_Street || ' ' || v_City || ' (' || v_branchNo || ')');
        DBMS_OUTPUT.PUT_LINE('Jenis Kelamin    : ' || v_Sex_Desc);     
        DBMS_OUTPUT.PUT_LINE('Jabatan          : ' || v_sPosition);
        DBMS_OUTPUT.PUT_LINE('Tanggal Lahir    : ' || TO_CHAR(v_DoB, 'DD-MON-YYYY'));
        DBMS_OUTPUT.PUT_LINE('Gaji             : ' || v_salary|| ' USD');
    END IF;
EXCEPTION 
    WHEN EmpNo_Out_of_range THEN
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Error: Nomor Staff tidak valid atau di luar jangkauan!');
    
    WHEN NO_DATA_FOUND THEN 
        DBMS_OUTPUT.PUT_LINE(chr(13));
        DBMS_OUTPUT.PUT_LINE('Error: Data Staff tidak ditemukan!');
END;
/
