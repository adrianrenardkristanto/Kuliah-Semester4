SET SERVEROUTPUT ON;

DECLARE
    CURSOR staff_cursor IS
        SELECT Fname, Lname, BranchNo, Salary
        FROM staff
        ORDER BY BranchNo ASC, Salary DESC;
    
    v_Fname staff.Fname%TYPE;
    v_Lname staff.Lname%TYPE;
    v_BranchNo staff.BranchNo%TYPE;
    v_Salary staff.Salary%TYPE;
    v_PrevBranchNo staff.BranchNo%TYPE := NULL;
BEGIN
    DBMS_OUTPUT.PUT_LINE('======================================');
    DBMS_OUTPUT.PUT_LINE('           Test Report               ');
    DBMS_OUTPUT.PUT_LINE('======================================');
    DBMS_OUTPUT.PUT_LINE('Nama   | Staff  | Branch no | Salary ');
    DBMS_OUTPUT.PUT_LINE('--------------------------------------');
    
    FOR staff_rec IN staff_cursor LOOP
        -- Print a blank line when BranchNo changes
        IF v_PrevBranchNo IS NOT NULL AND v_PrevBranchNo <> staff_rec.BranchNo THEN
            DBMS_OUTPUT.PUT_LINE('');
        END IF;
        
        DBMS_OUTPUT.PUT_LINE(
            RPAD(staff_rec.Fname, 6) || ' | ' ||
            RPAD(staff_rec.Lname, 6) || ' | ' ||
            RPAD(staff_rec.BranchNo, 9) || ' | ' ||
            LPAD(staff_rec.Salary, 6)
        );
        
        v_PrevBranchNo := staff_rec.BranchNo;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('======================================');
END;
/
