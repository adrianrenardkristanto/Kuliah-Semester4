CREATE OR REPLACE PROCEDURE List_Client_Comments IS
    CURSOR cur_client_comments IS
        SELECT v.clientNo, 
               c.fName, 
               c.lName, 
               v.propertyNo, 
               p.street, 
               p.city, 
               p.pType, 
               p.rooms, 
               v.vComment
        FROM Viewing v
        JOIN CClient c ON v.clientNo = c.clientNo
        JOIN PropertyForRent p ON v.propertyNo = p.propertyNo
        WHERE v.vComment IS NOT NULL 
        ORDER BY v.clientNo;

    v_ClientNo     CClient.clientNo%TYPE;
    v_Fname        CClient.fName%TYPE;
    v_Lname        CClient.lName%TYPE;
    v_PropertyNo   PropertyForRent.propertyNo%TYPE;
    v_Street       PropertyForRent.street%TYPE;
    v_City         PropertyForRent.city%TYPE;
    v_PropertyType PropertyForRent.pType%TYPE;
    v_Rooms        PropertyForRent.rooms%TYPE;
    v_Comment      Viewing.vComment%TYPE;
    v_Count NUMBER := 0;

BEGIN
    DBMS_OUTPUT.PUT_LINE('=====================================================================================================================');
    DBMS_OUTPUT.PUT_LINE('| CLIENTNO | NAME                | PROPNO | STREET          | CITY      | PROP_TYPE | ROOMS | CLIENT_COMMENT      |');
    DBMS_OUTPUT.PUT_LINE('=====================================================================================================================');
    OPEN cur_client_comments;
    LOOP
        FETCH cur_client_comments INTO v_ClientNo, v_Fname, v_Lname, v_PropertyNo, v_Street, v_City, v_PropertyType, v_Rooms, v_Comment;
        EXIT WHEN cur_client_comments%NOTFOUND; 
        
        DBMS_OUTPUT.PUT_LINE('| ' || RPAD(v_ClientNo, 8) || ' | ' ||
                                 RPAD(v_Fname || ' ' || v_Lname, 18) || ' | ' ||
                                 RPAD(v_PropertyNo, 6) || ' | ' ||
                                 RPAD(v_Street, 14) || ' | ' ||
                                 RPAD(v_City, 9) || ' | ' ||
                                 RPAD(v_PropertyType, 9) || ' | ' ||
                                 LPAD(v_Rooms, 5) || ' | ' ||
                                 RPAD(v_Comment, 20) || ' |');

        v_Count := v_Count + 1;
    END LOOP;
    IF v_Count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('| Data not found                                                                                      |');
    END IF;
    DBMS_OUTPUT.PUT_LINE('=====================================================================================================================');
    CLOSE cur_client_comments;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);

END List_Client_Comments;
/
